register("messageSent", (message, event) => {
    if (message.toLowerCase().includes("!cps")) {
        setTimeout(function() {
            ChatLib.chat(CPS.getLeftClicks()+" CPS")
        }, 1000);
    }
  });